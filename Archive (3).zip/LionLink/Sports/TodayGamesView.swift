//
//  TodayGamesView.swift
//  LionLink
//
//  Created by Liam Bean on 1/9/25.
//

import SwiftUI

struct TodayGamesView: View {
    
    var body: some View {
        GeneralNavBar(title:"Sports")
        VStack(){
            HStack(){
                Text("Today's Games")
                    .font(.system(size:30))
                    .bold()
                Spacer()
            }.padding()
            GameListView()
            Spacer()
            
        }
        .ignoresSafeArea()
        .scenePadding()
    }
}

#Preview {
    TodayGamesView()
}

struct GameListView: View {
    var body: some View{
        ScrollView(.horizontal, showsIndicators:false){
            HStack{
                ForEach(0..<100) {number in
                    ZStack{
                        Image("BurgerKing")
                            .frame(width:330)
                            .scaledToFit()
                            .frame(height:300)
                        Text("Hamburger")
                            .font(.system(size:40))
                            .frame(width:330)
                            .foregroundStyle(.white)
                            .background(.black)
                            .padding(.top,250)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                }.containerRelativeFrame(.horizontal, alignment:.center)
            }
        }
            .scrollTargetLayout()
            .scrollTargetBehavior(.viewAligned)
            
    }
}
