import SwiftUI

struct TeamPgMain: View {
    @StateObject var viewModel = TeamGridViewModel()
    var body: some View {
        VStack{
            TodayGamesView()
            
            MyPracticesView()
        }
//        NavigationView{
//            List( ){
//                ForEach(MockTeamData.teams){ team in
//                    NavigationLink(destination: TeamDetailView(team:team)){
//                        TeamTitleView(team: team)
//                    }
//                }
//            }
//            .navigationTitle("Teams")
//        }
//        .tint(Color.white)
    }
}

