//
//  MyPracticesView.swift
//  LionLink
//
//  Created by Liam Bean on 1/14/25.
//

import SwiftUI

struct MyPracticesView: View {
    var body: some View {
        VStack(){
            HStack(){
                Text("My Practices")
                    .font(.system(size:30))
                    .bold()
                Spacer()
            }.padding()
            NavigationLink {
                PracticeScheduleView()
            } label: {
                Text(">Schedule<")
                    .frame(width:300,height:100)
                    .foregroundStyle(.whiteNBlack)
                    .background(.dinnerGreen)
                    .font(.system(size:30))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding()
            }
           
            Spacer()
        }
        .ignoresSafeArea()
        .scenePadding()
        
    }
}

#Preview {
    MyPracticesView()
}


struct PracticeScheduleView: View {
    var body: some View {
        Text("jo_")
    }
}

#Preview {
    PracticeScheduleView()
}
