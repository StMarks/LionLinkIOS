//
//  ForumsMainView.swift
//  LionLink
//
//  Created by Liam Bean on 11/14/24.
//

//import SwiftUI
//
//struct ForumsMainView: View {
//    var body: some View {
//        GeneralNavBar(title:"Forums")
//        VStack(alignment:.leading){
//            Text("Speak Your Mind")
//                .font(.system(size:40))
//                .fontDesign(.serif)
//            ForumTab(title:"Why is Ligma so Sigma?")
//            ForumTab(title:"Why is Sigma so Ligma?")
//
//            ForumTab(title:"Candy good for teef?")
//
//            ForumTab(title:"What is 3*2x?")
//
//            ForumTab(title:"Why is Ligma so Sigma?")
//
//            
//            Spacer()
//        }
//    }
//}
//
//struct ForumTab: View {
//    let title: String
//    
//    var body: some View {
//        VStack(alignment:.leading){
//                VStack(alignment: .leading){
//                    Text(title)
//                        .font(.system(size:20))
//                                    }.foregroundStyle(.black)
//                    .padding()
//                    .frame(width:350,alignment:.leading)
//                    .background(.white)
//                    .clipShape(RoundedRectangle(cornerRadius: 20))
//        }
//    }
//}
//
//#Preview {
//    ForumsMainView()
//}
