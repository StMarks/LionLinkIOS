//
//  LunchDayView.swift
//  LionLink
//
//  Created by Liam Bean on 10/28/24.
//

import SwiftUI
import UIKit
struct LunchDayView: View {
    let lunchService: LunchService
    let dailyMenus: [DailyMenu]
    let todayId: Int
    let todayDate: String
//    @State private var activeTab: [DailyMenu]
    var body: some View {
        ScrollViewReader { proxy in
            VStack{
//                Button{
//                    proxy.scrollTo(todayDate,anchor:.leading)
//                    proxy.scrollTo(todayId, anchor:.center)
//                }label:{
//                    Text("Today's Menu")
//                        .bold()
//                        .fontDesign(.default)
//                        .foregroundStyle(.white)
//                        .frame(width:120,height:50)
//                }
                DayLunch(lunchService: lunchService,dailyMenus:dailyMenus,todayId:todayId,proxy:proxy)
//                NavView(lunchService: lunchService, dailyMenus: dailyMenus, todayId: todayId, todayDate: todayDate)
//                LunchTabs(lunchService: lunchService, dailyMenus: dailyMenus,todayId: todayId, todayDate: todayDate)
                Spacer()
                //BELOW IS NON FUNCTIONAL
                
                
                //                TabView(selection:$activeTab){
                //                    ForEach(dailyMenus, id:\.id){menu in
                //                        VStack{
                //                            Text("ID: \(menu.id)")
                //                            Text("\(lunchService.formatDateFromMenu(from:menu.date)!)").padding()
                //
                //                            if !menu.lunchContents.isEmpty {
                //                                Text("Breakfast: \(menu.breakfastContents.joined(separator: ", "))").padding()
                //                            }
                //
                //                            if !menu.lunchContents.isEmpty {
                //                                Text("Lunch: \(menu.lunchContents.joined(separator: ", "))").padding()
                //                            }
                //
                //                            if !menu.dinnerContents.isEmpty {
                //                                Text("Dinner: \(menu.dinnerContents.joined(separator: ", "))").padding()
                //                            }
                //                        }
                //                        .tag(menu.id)
                //                        .padding()
                //                        .background(Color.blue.opacity(0.5))
                //                        .foregroundColor(Color.white)
                //                        .cornerRadius(20)
                //                        .frame(width:300,height:500,alignment:.center)
                //
                //                    }
                //
                //
                //                    }
                //                }
                //                .onAppear(){
                //                    self.activeTab = todayId
                //                }
                //
                //                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                //
                //
                
                //BELOW IS FUNCTIONAL
                
                ScrollView(.horizontal, showsIndicators: false){
                    HStack(spacing:0){
                        ForEach(dailyMenus, id:\.id){ menu in
                            VStack{
                                Text("\(lunchService.formatDateFromMenu(from: menu.date)!)")
                                    .font(.system(size:40))
                                    .fontDesign(.serif)
//                            RoundedRectangle(cornerRadius: 20)
//                                .fill(Color.blue.opacity(0.5))
//                                .frame(width:350,height:500)
//                                .overlay(alignment:.leading){

                                ScrollView(showsIndicators:false){
                                    VStack{
                                        if !menu.breakfastContents.isEmpty {
                                            LunchRec(title:"Breakfast",text:"\(menu.breakfastContents.joined(separator: "\n-"))",color:.breakfastRed)
                                                .padding(5)
                                                
                                            //                                                Text("Breakfast: \(menu.breakfastContents.joined(separator: ", "))")
                                            //                                                    .padding()
                                            //                                                    .frame(width:350)
                                            //                                                    .background(.blue)
                                            //
                                            //                                                    .clipShape(RoundedRectangle(cornerRadius:10))
                                        }
                                        
                                        if !menu.lunchContents.isEmpty {
                                            LunchRec(title:"Lunch",text:"\(menu.lunchContents.joined(separator: "\n-"))",color:.lunchYellow)
                                                .padding(5)
                                            
                                            //                                                Text("Lunch: \(menu.lunchContents.joined(separator: ", "))")
                                            //                                                    .padding()
                                        }
                                        
                                        if !menu.dinnerContents.isEmpty {
                                            LunchRec(title:"Dinner",text:"\(menu.dinnerContents.joined(separator: "\n-"))",color:.dinnerGreen)
                                                .padding(5)
                                                
                                            //                                                Text("Dinner: \(menu.dinnerContents.joined(separator: ", "))")
                                            //                                                    .padding()
                                        }
                                        
                                                                            
                                    }.background(.white.opacity(0.2))
                                        .clipShape(RoundedRectangle(cornerRadius:20))
                                }.scrollTargetLayout()
                                    .scrollTargetBehavior(.viewAligned)
//                                    ScrollView(showsIndicators:false){
//                                        VStack(alignment:.leading){
//                                            if !menu.lunchContents.isEmpty {
//                                                LunchRec(title: "Breakfast:", text:"\(menu.breakfastContents.joined(separator: ", "))")
//                                                    .padding()
//                                            }
//                                            
//                                            if !menu.lunchContents.isEmpty {
//                                                LunchRec(title:"Lunch:",text:"\(menu.lunchContents.joined(separator: ", "))")
//                                                    .padding()
//                                            }
//                                            
//                                            if !menu.dinnerContents.isEmpty {
//                                                LunchRec(title:"Dinner:", text:"\(menu.dinnerContents.joined(separator: ", "))")
//                                                    .padding()
//                                            }
//                                        }.scenePadding()
//                                    }.scrollTargetLayout()
//                                    .scrollTargetBehavior(.viewAligned)
                                }
                                .scrollTransition(.interactive){content, phase in
                                    content
                                        .opacity(phase.isIdentity ?1:0)
                                        .scaleEffect(phase.isIdentity ?1:0.7)
                                    
                                }
                                .containerRelativeFrame(.horizontal, alignment:.center)
                                .onAppear(){
                                    proxy.scrollTo(todayId,anchor:.center)
                                }
                            .onAppear(){
                                proxy.scrollTo(todayDate,anchor:.leading)
                            }
                            
                        }.onAppear(){
                            proxy.scrollTo(todayId)
                            
                        }
                        //                                    .scenePadding()
                    }
                    }
                    .scrollTargetLayout()
                    .scrollTargetBehavior(.viewAligned)
                    .contentMargins(10)
                    .onAppear(){
                        proxy.scrollTo(todayId)
                        
                    }
                    
                }
            
        }
    }
}

struct DayLunch: View {
    let lunchService: LunchService
    let dailyMenus: [DailyMenu]
    let todayId: Int
    let proxy: ScrollViewProxy
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false){
            HStack{
                ForEach(dailyMenus, id:\.date){ menu in
                    VStack{
                        Button(){
                            proxy.scrollTo(menu.id,anchor:.center)
                        }label:{
                            Text("\(lunchService.formatDateFromMenu(from: menu.date)!)")
                                .frame(minWidth:20,idealWidth:UIScreen.screenWidth/6,maxWidth: 200,minHeight: 30,idealHeight:80,maxHeight:90)
                                .background(Color.blue)
                                .cornerRadius(10)
                                .foregroundColor(Color.white) //CHANGE
                        }
                        
                    }.scrollTransition(.interactive){content, phase in
                        content
                            .opacity(phase.isIdentity ?1:0)
                            .scaleEffect(phase.isIdentity ?1:0.7)
                        
                    }
                    
                }
            }.ignoresSafeArea()
        }.ignoresSafeArea()
            .scenePadding()

        .scrollTargetLayout()
            .scrollTargetBehavior(.viewAligned)
    }
}
extension UIScreen{
   static let screenWidth = UIScreen.main.bounds.size.width
   static let screenHeight = UIScreen.main.bounds.size.height
   static let screenSize = UIScreen.main.bounds.size
}

struct LunchRec: View{
    let title: String
    let text: String
    let color: Color
    @State var lines: Int = 1
    @State var expanded: Bool = true
    var body: some View{
        VStack(alignment:.leading){
//            Button{
//                expanded.toggle()
//            }label:{
                VStack(alignment: .leading){
                    Text(title)
                        .font(.system(size:40))
                    if expanded{
                        Text("-"+text)
                            .font(.system(size:20))
                            .multilineTextAlignment(.leading)
                        
                    }
                }
                    .padding()
                    .frame(width:350,alignment:.leading)
                    .background(color)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .animation(.easeInOut(duration:0.1),value:expanded)
//            }.buttonStyle(NoTapAnimationStyle())
                
        }
    }
}


struct NoTapAnimationStyle: PrimitiveButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            // Make the whole button surface tappable. Without this only content in the label is tappable and not whitespace. Order is important so add it before the tap gesture
            .onTapGesture(perform: configuration.trigger)
    }
}
