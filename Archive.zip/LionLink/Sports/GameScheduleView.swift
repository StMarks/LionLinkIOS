//
//  GameScheduleView.swift
//  LionLink
//
//  Created by Liam Bean on 10/14/24.
//

import SwiftUI

struct GameScheduleView: View {
    let team: Team
    let viewModel = DetailViewModel()
    @Binding var isShowingGameScheduleView: Bool
    var body: some View {
        XDismissButton(isShowingGameScheduleView: $isShowingGameScheduleView)
        Spacer()
        Text("Whats the schedule?")
    }
}

#Preview {
    GameScheduleView(team:MockTeamData.sampleTeam, isShowingGameScheduleView:.constant(false))
}
