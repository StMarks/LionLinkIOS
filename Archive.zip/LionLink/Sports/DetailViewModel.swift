//
//  DetailViewModel.swift
//  LionLink
//
//  Created by Liam Bean on 10/14/24.
//

import Foundation
final class DetailViewModel: ObservableObject{
//    var selectedTeam: Team?{
//        didSet { isShowingGameScheduleView=true }
//    }
    //Above code doesn't need to be used I think
    
    @Published var isShowingGameScheduleView = false
}
