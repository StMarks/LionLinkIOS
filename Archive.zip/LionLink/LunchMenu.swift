//
//  LunchMenu.swift
//  LionLink
//
//  Created by Lion Link on 4/19/24.
//

import SwiftUI

struct LunchMenu: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    LunchMenu()
}
