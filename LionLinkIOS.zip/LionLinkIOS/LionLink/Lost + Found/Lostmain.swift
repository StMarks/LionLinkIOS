import SwiftUI

struct Lostmain: View {
    var body: some View {
        Text("LOST AND FOUND")
    }
}

#Preview {
    Lostmain()
}
