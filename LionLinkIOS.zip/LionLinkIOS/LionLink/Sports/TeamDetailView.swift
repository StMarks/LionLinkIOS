//
//  TeamDetailView.swift
//  LionLink
//
//  Created by Liam Bean on 10/14/24.
//

import SwiftUI

struct TeamDetailView: View {
    var team: Team
    
    @StateObject var viewModel = DetailViewModel()
    var body: some View {
        VStack{
            TeamTitleView(team: team)
                .frame(width: 300, height:150)
        
            Text(team.description)
                .font(.body)
                .padding()
            Text("Members: \n"+team.members.joined(separator: ", "))
                .font(.body)
                .padding()
                .frame(width:350)
            Spacer()
          
            Button {
                viewModel.isShowingGameScheduleView = true
            }label:{
                Label("View Game Schedule",systemImage:"book.fill")
            }
            .padding()
                
            
            Spacer()
              
        }
        .fullScreenCover(isPresented: $viewModel.isShowingGameScheduleView, content: {
            GameScheduleView(team:team, isShowingGameScheduleView: $viewModel.isShowingGameScheduleView)
        })
        
    }
}

#Preview {
    TeamDetailView(team:MockTeamData.sampleTeam)
}
