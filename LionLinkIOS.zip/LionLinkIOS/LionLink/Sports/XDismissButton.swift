//
//  XDismissButton.swift
//  LionLink
//
//  Created by Liam Bean on 10/14/24.
//

//  XDismissButton.swift
//  Apple-Frameworks
//
//  Created by Liam Bean on 10/8/24.
//

import SwiftUI

struct XDismissButton: View {
    
    @Binding var isShowingGameScheduleView: Bool
    
    var body: some View {
        HStack{
            Spacer()
            
            Button{
                isShowingGameScheduleView = false
            } label:{
                Image(systemName: "xmark")
                    .foregroundColor(Color(.label))
                    .imageScale(.large)
                    .frame(width:44,height:44)
            }
        }
        .padding()
    }
    
}

#Preview {
    XDismissButton(isShowingGameScheduleView: .constant(false))
}
