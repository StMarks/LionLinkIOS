//
//  TeamTitleView.swift
//  LionLink
//
//  Created by Liam Bean on 10/14/24.
//

import SwiftUI

struct TeamTitleView: View {
    let team: Team
    var body: some View {
        HStack{
            Image(team.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 70, height: 70)
                
                
            Text(team.name)
                .font(.title2)
                .fontWeight(.semibold)
                .scaledToFit()
                .minimumScaleFactor(0.5)
                .padding()
        }
        
        
    }

}

#Preview {
    TeamTitleView(team:MockTeamData.sampleTeam)
}
