//
//  TeamGridViewModel.swift
//  LionLink
//
//  Created by Liam Bean on 10/14/24.
//


import Foundation
import SwiftUI

final class TeamGridViewModel: ObservableObject{
//    var selectedTeam: Team?{
//        didSet { isShowingDetailView=true }
//    }
    
    @Published var isShowingDetailView = false
    
    let columns: [GridItem] = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
}
